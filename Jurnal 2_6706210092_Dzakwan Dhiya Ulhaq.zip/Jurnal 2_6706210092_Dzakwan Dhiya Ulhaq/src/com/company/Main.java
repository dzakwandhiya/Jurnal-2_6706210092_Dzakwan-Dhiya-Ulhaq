package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        GenericArrayList<Atk> atkList = new GenericArrayList<>(5);
        GenericArrayList<Bag> bagList = new GenericArrayList<>(5);
        String kodeBarang;
        String jenisBarang;
        String namaBarang;
        int stokSekarang;
        int opsiObject = 0;

        while (opsiObject != 3) {
            System.out.println("Pilih Object Inputan :");
            System.out.println("1. ATK");
            System.out.println("2. BAG");
            System.out.println("3. Keluar");
            opsiObject = input.nextInt();
            if (opsiObject == 1) {
                while (opsiObject != 5) {
                    System.out.println("Pilih menu ATK :");
                    System.out.println("1. Input data barang :");
                    System.out.println("2. Edit data barang :");
                    System.out.println("3. Hapus data barang :");
                    System.out.println("4. Cetak data barang :");
                    System.out.println("5. Kembali :");
                    int pilihan = input.nextInt();

                    if (pilihan == 1) {
                        System.out.println("Masukkan kode, jenis, nama dan stok Barang");
                        for (int i = 0; i < 5; i++) {
                            kodeBarang = input.next();
                            jenisBarang = input.next();
                            namaBarang = input.next();
                            stokSekarang = input.nextInt();
                            atkList.addData(new Atk(kodeBarang, jenisBarang, namaBarang, stokSekarang));
                            atkList.sort();
                        }
                    } else if (pilihan == 2) {
                        System.out.println("Index Data Ke berapa yang akan diedit ? :");
                        int index = input.nextInt();
                        System.out.println("Masukkan Data edit :");
                        kodeBarang = input.next();
                        jenisBarang = input.next();
                        namaBarang = input.next();
                        stokSekarang = input.nextInt();

                        Atk editAtk = new Atk(kodeBarang, jenisBarang, namaBarang, stokSekarang);
                        atkList.editData(index, editAtk);

                    } else if (pilihan == 3) {
                        System.out.println("Index Data Ke berapa yang akan dihapus ? :");
                        int index = input.nextInt();
                        atkList.removeData(index);

                    } else if (pilihan == 4) {
                        atkList.display();
                        //atkList.displaySort();
                    } else if (pilihan == 5) {
                        break;
                    }
                }
            } else if (opsiObject == 2) {
                while (opsiObject != 5) {
                    System.out.println("Pilih menu BAG : ");
                    System.out.println("1. Input data barang :");
                    System.out.println("2. Edit data barang :");
                    System.out.println("3. Hapus data barang :");
                    System.out.println("4. Cetak data barang :");
                    System.out.println("5. Kembali :");
                    int pilihan = input.nextInt();

                    if (pilihan == 1) {
                        System.out.println("Masukkan kode, jenis, nama dan stok Barang");
                        for (int i = 0; i < 5; i++) {
                            kodeBarang = input.next();
                            jenisBarang = input.next();
                            namaBarang = input.next();
                            stokSekarang = input.nextInt();
                            bagList.addData(new Bag(kodeBarang, jenisBarang, namaBarang, stokSekarang));
                            bagList.sort();
                        }
                    } else if (pilihan == 2) {
                        System.out.println("Index Data Ke berapa yang akan diedit ? :");
                        int index = input.nextInt();
                        System.out.println("Masukkan Data edit :");
                        kodeBarang = input.next();
                        jenisBarang = input.next();
                        namaBarang = input.next();
                        stokSekarang = input.nextInt();

                        Bag editBag = new Bag(kodeBarang, jenisBarang, namaBarang, stokSekarang);
                        bagList.editData(index, editBag);

                    } else if (pilihan == 3) {
                        System.out.println("Index Data Ke berapa yang akan dihapus ? :");
                        int index = input.nextInt();
                        bagList.removeData(index);

                    } else if (pilihan == 4) {
                        bagList.display();
                        //bagList.displaySort();
                    } else if (pilihan == 5) {
                        break;
                    }

                }

            }

        }

    }

}

