package com.company;

import java.util.*;

public class GenericArrayList<E extends Comparable <? super E>>{
    private ArrayList<E> list;

    public GenericArrayList(int capacity){
        int initCapacity = capacity > 0? capacity:0;
        list = new ArrayList<>(initCapacity);
    }

    public void addData(E values){
        list.add(values);
    }

    public void display(){
        for(int i = 0; i < list.size(); i++){
            System.out.printf(list.get(i) + "\n");
        }
        System.out.println();
    }
    public void sort(){
        Collections.sort(list);
    }
    public void displaySort(){
        Collections.sort(list, new Comparator<E>(){
            @Override
            public int compare(E o1, E o2){
                return o1.compareTo(o2);

            }
        });
        for(int i = 0; i < list.size(); i++){
            System.out.printf(list.get(i) + " ");
        }
        System.out.println();

    }

    public void removeData(int entry){
        list.remove(entry);
    }

    public void editData(int index, E object2){
        //int index = list.indexOf(object1);
        list.set(index, object2);
    }

}
