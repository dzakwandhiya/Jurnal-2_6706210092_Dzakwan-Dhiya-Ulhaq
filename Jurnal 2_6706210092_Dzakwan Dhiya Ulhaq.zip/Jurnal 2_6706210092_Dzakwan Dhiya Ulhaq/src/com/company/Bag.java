package com.company;

public class Bag implements Comparable<Bag> {
    private String kodeBarang;
    private String jenisBarang;
    private String namaBarang;
    private int stokSaatIni;

    public Bag(String kodeBarang, String jenisBarang, String namaBarang, int stokSaatIni){
        if(!(kodeBarang.split("")[0].equals("C"))){
            throw new IllegalArgumentException("Input kode barng bukan (C)");
        }
        this.kodeBarang = kodeBarang;
        this.jenisBarang = jenisBarang;
        this.namaBarang = namaBarang;
        this.stokSaatIni = stokSaatIni;

    }

    public String toString(){
        return "{" + kodeBarang +
                " | " + jenisBarang +
                " | " + namaBarang +
                " | " + stokSaatIni + "}";
    }

    public String getKodeBarang(){
        return kodeBarang;
    }

    public int compareTo(Bag o){
        return this.getKodeBarang().compareTo(o.getKodeBarang());
    }



}

