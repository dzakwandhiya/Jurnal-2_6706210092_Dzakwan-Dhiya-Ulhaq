package com.company;


public class Atk implements Comparable<Atk>{
    private String kodeBarang;
    private String jenisBarang;
    private String namaBarang;
    private int stokSaatIni;

    public Atk(String kodeBarang, String jenisBarang, String namaBarang, int stokSaatIni){
        if(!(kodeBarang.split("")[0].equals("A") || kodeBarang.split("")[0].equals("B"))){
            throw new IllegalArgumentException("Input kode barng bukan (A/B)");
        }
        this.kodeBarang = kodeBarang;
        this.jenisBarang = jenisBarang;
        this.namaBarang = namaBarang;
        this.stokSaatIni = stokSaatIni;

    }
    @Override
    public String toString(){
        return "{" + kodeBarang +
                " | " + jenisBarang +
                " | " + namaBarang +
                " | " + stokSaatIni + "}";
    }

    public String getKodeBarang(){
        return kodeBarang;
    }
    @Override
    public int compareTo(Atk o){
        return this.getKodeBarang().compareTo(o.getKodeBarang());
    }



}
